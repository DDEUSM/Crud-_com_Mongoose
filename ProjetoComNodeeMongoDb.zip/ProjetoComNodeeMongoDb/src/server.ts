import express,{Request, Response} from 'express'
import dotenv from 'dotenv'
import path from 'path'
import mustache from 'mustache-express';
import mainRouter from './routes'

dotenv.config();

const server = express();

server.set('view engine', mustache)
server.set('view', path.join(__dirname, "./view"))
server.engine('mustache', mustache())

server.use(express.static(path.join(__dirname, '../public')));

server.use(mainRouter)

server.listen(process.env.PORT);