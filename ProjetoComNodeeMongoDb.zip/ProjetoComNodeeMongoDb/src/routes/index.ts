import {Router, Request, Response} from 'express';
import * as controll from '../controller/home.control'

const router = Router();

router.get('/', controll.home)

export default router